package com.hexaware.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("emailService")
public class EmailService {
	DataSources obj1=null;
	DataSources obj2=null;

    @Autowired
    public EmailService(DataSources obj) {
        this.obj1=obj;
        System.out.println("constructor inject Bean for MySqlDataSource: " +this.obj1);
    }

    public void sendEmail() {
        obj1.returnConnection();
        System.out.println("Email sent.");
    }
}
