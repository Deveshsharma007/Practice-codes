package com.hexaware.demo;

public interface DataSources {
	public void returnConnection();

}
