package com.hexaware.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sampleapp2Application {

	public static void main(String[] args) {
		SpringApplication.run(Sampleapp2Application.class, args);
	}

}
