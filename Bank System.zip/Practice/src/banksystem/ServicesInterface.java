package banksystem;

import javax.security.auth.login.AccountNotFoundException;

import banksystem.exceptions.InsufficientFundsException;
import banksystem.exceptions.NegativeAmountException;

public interface ServicesInterface {

	BankAccount searchAccount(long accountNumber);
	double checkBalance(long accountNumber) throws AccountNotFoundException;
	boolean deposit(long accountNumber, double amount) throws NegativeAmountException, AccountNotFoundException;
	boolean withdraw(long accountNumber, double amount) throws AccountNotFoundException, NegativeAmountException, InsufficientFundsException;
	boolean createAccount(BankAccount newAcc);
	boolean removeAccount(long accountNumber) throws AccountNotFoundException;
}
