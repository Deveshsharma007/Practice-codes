package banksystem.exceptions;

public class AccountNotFoundException extends Exception{
	public AccountNotFoundException(String message) {
		super(message+"Bank account not found");
	}

}
