package banksystem;

import java.util.ArrayList;
import java.util.List;

public class Bank {
	private String name;
	private ArrayList<BankAccount> accountList=new ArrayList<>();
	
	public Bank() {
		super();
	}
	
	public Bank(String name, ArrayList<BankAccount> accountList) {
		super();
		this.name = name;
		this.accountList = accountList;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public List<BankAccount> getAccountList() {
		return accountList;
	}

	@Override
	public String toString() {
		return "Bank [name=" + name + ", accountList=" + accountList + "]";
	}
	
	
}
