package banksystem;

import java.util.logging.Logger;
import javax.security.auth.login.AccountNotFoundException;
import java.util.ArrayList;
import banksystem.exceptions.*;

public class Main {
	 private static final Logger LOGGER = Logger.getLogger(Main.class.getName());
	 
    public static void main(String[] args) throws InsufficientFundsException, NegativeAmountException, AccountNotFoundException {
    	LOGGER.info("Hello Everyone!\nProgram Execution started!");
    	 
        BankAccount obj1 = new BankAccount(101,"Devesh", "Current", 80000.50);
		BankAccount obj2 = new BankAccount(102,"Suchit", "Savings", 20000.50);
		BankAccount obj3 = new BankAccount(103,"Vansh", "Current", 35000.50);
		ArrayList<BankAccount> myList = new ArrayList<>();
		myList.add(obj1);
		myList.add(obj2);
		myList.add(obj3);
		Bank myBank = new Bank("ICICI", myList);
		System.out.println(myBank);
		ServicesInterfaceImpl myServiceObj = new ServicesInterfaceImpl(myBank);
		
		try {
			LOGGER.info("Balance of account 101: " + myServiceObj.checkBalance(101));
		} catch (AccountNotFoundException e) {
			throw new AccountNotFoundException("Bank account does not exists.");
		}
		
		try {
			System.out.println("Balance of account 101 : " + myServiceObj.checkBalance(101));
		} 
		catch (AccountNotFoundException e) {
			throw new AccountNotFoundException("Bank account does not exists.");
		}
		
        try {
        	LOGGER.info("Depositing into Account");
			System.out.println("Status of deposit: " + myServiceObj.deposit(102, 50000.50));
			System.out.println("Balance of account 102 : " + myServiceObj.checkBalance(102));
			LOGGER.info("Deposited into Account");
		}
        catch (AccountNotFoundException e) {
			throw new AccountNotFoundException("Bank account does not exists.");
		}
        catch (NegativeAmountException e) {
			throw new NegativeAmountException("Amount should be positive.");
		}
        
        try {
        	LOGGER.info("Withdrawing from Account");
        	System.out.println("Withdraw from account 101 : " + myServiceObj.withdraw(101, 25000.00));
			System.out.println("Balance of account 101 : " + myServiceObj.checkBalance(101));
			LOGGER.info("Withdrawal done");
		} 
        catch (AccountNotFoundException e) {
			throw new AccountNotFoundException("Bank account does not exists.");
		}
        
        try {
			System.out.println("remove account status " + myServiceObj.removeAccount(103));
        }
        catch (AccountNotFoundException e){
        	throw new AccountNotFoundException("Bank account does not exists.");
        }
        System.out.println(myBank);
        LOGGER.info("Program Execution completed!");
     }
}