package string;

public class StringBuilderClass {
	public static StringBuilder addingNewString(String str1,String str2) {
		StringBuilder newString=new StringBuilder(100);
		newString.append(str1);
		newString.append(str2);
		
		return newString;
	}
	
	public static StringBuilder addAtIndex(int index,String str1,String str2) {
		StringBuilder newString2=new StringBuilder(100);
		newString2.append(str1);
		newString2.insert(index,str2);
		
		return newString2;
	}
	
	public static StringBuilder deleteAPortion(int start, int end,String str) {
		StringBuilder newString3=new StringBuilder(100);
		newString3.append(str);
		newString3.delete(start, end);
		
		return newString3;
		
	}
	
	public static void main(String[] args) {
		String str1=new String("Hello,");
		String str2=" Everyone ";
		
		System.out.println("Adding new string 'Sharma' to existing string\nThe new String is: "+addingNewString(str1,str2));
		
		System.out.println("\nAdding new string 'Sharma' at specific location \nThe new String is: "+addAtIndex(0,str1,str2));
		
		System.out.println("\nDeleting a substring \nThe new String is: "+deleteAPortion(2,4,str1));
	}

}


/*
Build a simplified version of the StringBuilder class.
Your custom class should support basic string manipulation operations such as: 
Appending a string.
Inserting a string at a specific index.
Deleting a portion of the string
*/