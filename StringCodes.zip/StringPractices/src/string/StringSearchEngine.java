package string;

import java.util.ArrayList;
import java.util.List;

public class StringSearchEngine {
	private String originalText;
	
    public static int findStringOccurences(String str1,String str2) {
    	int lastIndex = 0;
    	int count = 0;
    	while (lastIndex != -1) {
    	    lastIndex = str1.indexOf(str2, lastIndex);

    	    if (lastIndex != -1) {
    	        count++;
    	        lastIndex += str2.length();
    	    }
    	}
    	return count;
    }
    public StringSearchEngine(String originalText) {
        this.originalText = originalText;
    }

    public List<Integer> findAllOccurrences(String substring) {
        List<Integer> occurrences = new ArrayList<>();
        int index = originalText.indexOf(substring);

        while (index != -1) {
            occurrences.add(index);
            index = originalText.indexOf(substring, index + 1);
        }

        return occurrences;
    }
    
    public String highlightOccurrences(String substring) {
        String highlightedText = originalText;
        List<Integer> occurrences = findAllOccurrences(substring);

        for (int i = occurrences.size() - 1; i >= 0; i--) {
            int start = occurrences.get(i);
            int end = start + substring.length();
            highlightedText = highlightedText.substring(0, start) +
                    "$" + highlightedText.substring(start, end) + "$" +
                    highlightedText.substring(end);
        }

        return highlightedText;
    }
    
    public static void main(String[] args) {
    	String str1="Hello my name is devesh!, Hello everyone!";
    	StringSearchEngine newStr = new StringSearchEngine(str1);
    	String str2="Hello";
    	System.out.println("Total occurences of "+str2+" is: "+findStringOccurences(str1,str2));
    	List<Integer> occurrences = newStr.findAllOccurrences(str2);
        System.out.println("Occurrences of '" + str2 + "': " + occurrences);

        String highlightedText = newStr.highlightOccurrences(str2);
        System.out.println("Highlighted Text: " + highlightedText);
    }
}
