package string;

import java.util.Scanner;
import string.UrlParser;

public class UrlBuilder {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String preDefined="https://www.";
		System.out.println("Enter the url");
		String url=sc.next();
		System.out.println("Enter the domain");
		String domain=sc.next();
		System.out.println("Enter the path");
		String path=sc.next();
		
		UrlParser obj=new UrlParser(preDefined,url,domain,path);
		System.out.println(obj.toString()+"\n");
		
		StringBuilder yourURL=new StringBuilder();
		yourURL.append(preDefined);
		yourURL.append(url);
		yourURL.append(domain);
		yourURL.append("/");
		yourURL.append(path);
		
		System.out.println("Final URL is:-  "+yourURL);
	
	}
}
