package string;

public class UrlParser {
	String http;
	String url;
	String domain;
	String path;
	
	public UrlParser() {
		//default constructor
	}
	
	public UrlParser(String http,String url,String domain,String path) {
		this.http=http;
		this.url=url;
		this.domain=domain;
		this.path=path;
	}

	@Override
	public String toString() {
		return "UrlParser [http=" + http + ", host=" + url + ", domain=" + domain + ", path=" + path + "]";
	}
	
	

}
