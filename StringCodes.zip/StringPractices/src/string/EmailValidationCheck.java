package string;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailValidationCheck {
	
	public static void main(String[] args) {
		String email="Devesh@gmail.com";
		String symbols = "^(.+)@(.+)$"; 
		Pattern pattern = Pattern.compile(symbols); 
	    Matcher matcher = pattern.matcher(email);  
	    System.out.println(email +" : "+ matcher.matches()+"\n");   
	}
}
